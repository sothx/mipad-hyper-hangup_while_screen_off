# shellcheck disable=SC2148

MODDIR=${0%/*}
. "$MODDIR"/util_functions.sh
patch_device_features "$MODDIR"